/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export function compile_and_execute(a: number, b: number, c: number, d: number, e: number, f: number): void;
export function rust_psm_on_stack(a: number, b: number, c: number, d: number): void;
export function rust_psm_stack_direction(): number;
export function rust_psm_stack_pointer(): number;
export function rust_psm_replace_stack(a: number, b: number, c: number): void;
export function __wbindgen_export_0(a: number): number;
export function __wbindgen_export_1(a: number, b: number, c: number): number;
export function __wbindgen_add_to_stack_pointer(a: number): number;
export function __wbindgen_export_2(a: number): void;
