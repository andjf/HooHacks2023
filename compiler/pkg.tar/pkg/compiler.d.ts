/* tslint:disable */
/* eslint-disable */
/**
* @param {string} code
* @param {any} start_position
* @param {number} width
* @param {number} height
* @returns {any}
*/
export function compile_and_execute(code: string, start_position: any, width: number, height: number): any;
