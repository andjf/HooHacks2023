import * as wasm from "./compiler_bg.wasm";
import { __wbg_set_wasm } from "./compiler_bg.js";
__wbg_set_wasm(wasm);
export * from "./compiler_bg.js";
