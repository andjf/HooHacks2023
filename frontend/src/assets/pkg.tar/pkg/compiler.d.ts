/* tslint:disable */
/* eslint-disable */
/**
* @param {string} code
* @param {any} start_position
* @returns {any}
*/
export function compile_and_execute(code: string, start_position: any): any;
